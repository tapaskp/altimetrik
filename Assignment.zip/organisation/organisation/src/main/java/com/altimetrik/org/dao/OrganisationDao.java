package com.altimetrik.org.dao;

import org.springframework.stereotype.Repository;

import com.altimetrik.org.model.Employee;


public interface OrganisationDao {
	Employee getEmployeeByProject(int projectId);
	boolean dissociateEmployeeByEmpProject(int empCode,int projectCode);
}
