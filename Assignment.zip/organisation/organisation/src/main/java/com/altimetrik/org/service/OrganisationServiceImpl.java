package com.altimetrik.org.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altimetrik.org.dao.OrganisationDao;
import com.altimetrik.org.model.Employee;

@Service
public class OrganisationServiceImpl implements OrganisationService{

	@Autowired
	private OrganisationDao organisationDao;
	public Employee getEmployeeByProject(int projectId) {
		return organisationDao.getEmployeeByProject(projectId);
		
	}

	public boolean dissociateEmployeeByEmpProject(int empCode, int projectCode) {
		// TODO Auto-generated method stub
		return organisationDao.deleteEmployeeByEmpProject(empCode, projectCode);
	}

}
