package com.altimetrik.org.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altimetrik.org.model.Employee;

@Repository
public class OrganisationDaoImpl implements OrganisationDao {

	@Autowired
	DataSource dataSource;

	public Employee getEmployeeByProject(int empCode) {
		Employee emp = new Employee();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs =null;
		String query = "select * from emp e where empcode in (select empcode from dept_proj_emp where projcode=?)";
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, empCode);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				emp.setEmpcode(rs.getInt(1));
				emp.setEname(rs.getString(2));
				emp.setMgr(rs.getInt(3));
				// emp.setHiredate(new SimpleDateFormat("yyyy-MM-dd
				// HH:mm:ss").format(rs.getDate(4)));
				emp.setSalary(rs.getInt(5));
				emp.setComm(rs.getInt(6));
				// System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
			}
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				if (null != conn)
					conn.close();

			} catch (Exception e) {
				// TODO: handle exception
			}
			try {
				if (null != pstmt)
					pstmt.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
			try {
				if (null != rs)
					rs.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

		return emp;
	}

	public boolean dissociateEmployeeByEmpProject(int empCode, int projectCode) {
		String query = "delete  from dept_proj_emp  where empcode=? and projcode=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, empCode);
			pstmt.setInt(2, projectCode);
			int delete = pstmt.executeUpdate(query);
			//conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if (null != conn)
					conn.close();

			} catch (Exception e) {
				// TODO: handle exception
			}
			try {
				if (null != pstmt)
					pstmt.close();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		return true;
	}

}
