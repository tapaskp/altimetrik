package com.altimetrik.org.resource;

import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.altimetrik.org.exception.EmployeeNotFoundException;
import com.altimetrik.org.model.Employee;
import com.altimetrik.org.service.OrganisationServiceImpl;



@RestController(value = "Organisation API Endpoint")
@RequestMapping(value = "/api/v1/organisation/")
public class OrganisationController {

@Autowired
private OrganisationServiceImpl organisationService;

		
	@GetMapping("/get-employee")
	public ResponseEntity<Employee> getEmployeeByProject(@NotEmpty @RequestParam(value = "projectId") int projectId) {
		Employee emp =organisationService.getEmployeeByProject(projectId);
		//emp=null;
		 if(emp == null) {
	         throw new EmployeeNotFoundException( "Invalid project id : " +projectId);
	    }
		return new ResponseEntity<Employee>(emp, HttpStatus.OK);
	}
	@DeleteMapping("/delete-employee")
	public ResponseEntity<Boolean> dissociateEmployeeByProject(@RequestParam(value = "projectId") int projectCode,@RequestParam(value = "empCode") int empCode) {
		boolean flag =organisationService.dissociateEmployeeByEmpProject(empCode, projectCode);
		return new ResponseEntity<Boolean>(flag, HttpStatus.OK);
	}
}
