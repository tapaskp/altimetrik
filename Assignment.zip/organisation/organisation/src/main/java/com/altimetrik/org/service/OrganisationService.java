package com.altimetrik.org.service;

import com.altimetrik.org.model.Employee;


public interface OrganisationService {
	Employee getEmployeeByProject(int projectId);
	boolean dissociateEmployeeByEmpProject(int empCode,int projectCode);

}
